﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AppWeb.Migrations
{
    public partial class Profit : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>("Profit", "Dist", nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn("Profit", "Dist");
        }
    }
}
