﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AppWeb.Data;
using AppWeb.Models;

namespace AppWeb.Controllers
{
    public class DistsController : Controller
    {
        private readonly ShoppingContext _context;

        public DistsController(ShoppingContext context)
        {
            _context = context;
        }

        // GET: Dists
        public async Task<IActionResult> Index()
        {
            return View(await _context.Dist.ToListAsync());
        }

        // GET: Dists/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dist = await _context.Dist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (dist == null)
            {
                return NotFound();
            }

            return View(dist);
        }

        // GET: Dists/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Dists/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Item,DistDate,Category,Price,Profit")] Dist dist)
        {
            if (ModelState.IsValid)
            {
                _context.Add(dist);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(dist);
        }

        // GET: Dists/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dist = await _context.Dist.FindAsync(id);
            if (dist == null)
            {
                return NotFound();
            }
            return View(dist);
        }

        // POST: Dists/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Item,DistDate,Category,Price")] Dist dist)
        {
            if (id != dist.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(dist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DistExists(dist.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(dist);
        }

        // GET: Dists/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dist = await _context.Dist
                .FirstOrDefaultAsync(m => m.Id == id);
            if (dist == null)
            {
                return NotFound();
            }

            return View(dist);
        }

        // POST: Dists/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var dist = await _context.Dist.FindAsync(id);
            _context.Dist.Remove(dist);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DistExists(int id)
        {
            return _context.Dist.Any(e => e.Id == id);
        }
    }
}
