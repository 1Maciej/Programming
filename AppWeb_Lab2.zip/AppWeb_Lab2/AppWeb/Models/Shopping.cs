using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AppWeb.Models
{
    public class Shopping
    {
        [Required(ErrorMessage ="Musisz wype�ni� to pole!")]
        [Display(Name = "Identyfikator")]
        public int Id { get; set; }
        [Required(ErrorMessage = "Musisz wype�ni� to pole!")]
        [Display(Name = "Przedmiot")]
        public string Item { get; set; }
       
        [DataType(DataType.Date)]
        [Required(ErrorMessage = "Musisz wype�ni� to pole!")]
        [Display(Name = "Data zakupu")]
        public DateTime ShoppingDate { get; set; }
        [Required(ErrorMessage = "Musisz wype�ni� to pole!")]
        [Display(Name = "Kategoria(5-40 znak�w)")]
        [StringLength(40, MinimumLength = 5, ErrorMessage ="Kategoria musi mie� od 5 do 40 znak�w")]
        public string Category { get; set; }
        [Required(ErrorMessage = "Musisz wype�ni� to pole!")]
        
        [Display(Name = "Cena(max 5000z�)")]
        [Range(1, 5000,ErrorMessage ="Cena nie mo�e by� wi�ksza od 5000z� ani mniejsza od 1z�")]
        public decimal Price { get; set; }
    }
}
