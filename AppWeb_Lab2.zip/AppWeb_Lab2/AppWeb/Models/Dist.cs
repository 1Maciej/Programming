﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AppWeb.Models
{
    public class Dist
    {
        [Required(ErrorMessage = "Musisz wypełnić to pole!")]
        [Display(Name = "Identyfikator")]
        public int Id { get; set; }
        [Required(ErrorMessage = "Musisz wypełnić to pole!")]
        [Display(Name = "Przedmiot")]
        public string Item { get; set; }

        [DataType(DataType.Date)]
        [Required(ErrorMessage = "Musisz wypełnić to pole!")]
        [Display(Name = "Data sprzedaży")]
      
        public DateTime DistDate { get; set; }
        [Required(ErrorMessage = "Musisz wypełnić to pole!")]
        
        [Display(Name = "Kategoria(5-40 znaków)")]
        [StringLength(40, MinimumLength = 5, ErrorMessage = "Kategoria musi mieć od 5 do 40 znaków")]
        public string Category { get; set; }
        [Required(ErrorMessage = "Musisz wypełnić to pole!")]
        [Display(Name = "Cena(max 5000zł)")]
        [Range(1, 5000, ErrorMessage = "Cena nie może być większa od 5000zł ani mniejsza od 1zł")]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Musisz wypełnić to pole!")]
        [Display(Name = "Profit")]
        public int Profit { get; set; }
    }
}
