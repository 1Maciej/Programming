// Dummy class to group shared resources

namespace AppWeb

{
    public class SharedResource
    {
    }
}