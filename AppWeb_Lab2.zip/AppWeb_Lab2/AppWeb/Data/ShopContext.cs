using AppWeb.Models;
using Microsoft.EntityFrameworkCore;

namespace AppWeb.Data
{
    public class ShoppingContext : DbContext
    {
        public ShoppingContext(DbContextOptions<ShoppingContext> options)
        : base(options)
        {
        }
        public DbSet<Shopping> Shopping{ get; set; }
        public DbSet<AppWeb.Models.Dist> Dist { get; set; }
    }
}
