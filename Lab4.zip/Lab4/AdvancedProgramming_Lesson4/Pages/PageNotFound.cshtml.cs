using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Zadanie4.Pages
{
    public class PageNotFoundModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
