﻿using Zadanie4.Data;
using Zadanie4.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Zadanie4.Pages.Historia
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Wiadomości> Wiadomości { get;set; }

        public async Task OnGetAsync()
        {
            Wiadomości = await _context.Wiadomości.ToListAsync();
        }
    }
}
