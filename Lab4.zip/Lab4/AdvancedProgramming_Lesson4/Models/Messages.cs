﻿using System.ComponentModel.DataAnnotations;

namespace Zadanie4.Models
{
    public class Wiadomości
    {
        public int Id { get; set; }
        [Display(Name = "User")]
        public string UserName { get; set; }
        public string Wiadomośc { get; set; }
        public bool Authenticated { get; set; }
         
    }
}
