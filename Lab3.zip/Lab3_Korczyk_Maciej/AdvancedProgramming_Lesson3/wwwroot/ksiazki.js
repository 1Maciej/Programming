﻿const uriBooks = "https://localhost:44354/api/Book";
let books = null;
function getCount(data) {
    const el = $("#counter");
    let name = "książek";
    if (data) {
        if (data > 1) {
            name = "książek";
        }
        el.text(data + " " + name);
    } else {
        el.text("brak " + name);
    }
}
$(document).ready(function () {
    getData();
});
function getData() {
    $.ajax({
        type: "GET",
        url: uriBooks,
        cache: false,
        success: function (data) {
            const tBody = $("#books");
            $(tBody).empty();
            getCount(data.length);
            $.each(data, function (key, item) {
                const tr = $("<tr></tr>")
                    .append($("<td></td>").text(item.title))
                    .append($("<td></td>").text(item.author))
                    .append(
                        $("<td></td>").append(
                            $("<button>Edycja</button>").on("click", function () {
                                editItem(item.id);
                            })
                        )
                    )
                    .append(
                        $("<td></td>").append(
                            $("<button>Usuń</button>").on("click", function () {
                                deleteItem(item.id);
                            })
                        )
                    );
                tr.appendTo(tBody);
            });
            books = data;
        }
    });
}
function addBook() {
    const item = {
        title: $("#add-title").val(),
        author: $("#add-author").val()
    };
    $.ajax({
        type: "POST",
        accepts: "application/json",
        url: uriBooks + '/CreateBookItem',
        contentType: "application/json",
        data: JSON.stringify(item),
        error: function (jqXHR, textStatus, errorThrown) {
            alert("Something went wrong!", errorThrown, textStatus);
        },
        success: function (result) {
            getData();
            $("#add-title").val("");
            $("#add-author").val("");
        }
    });
}

function deleteItem(id) {
    $.ajax({
        url: uriBooks + "/" + id,
        type: "DELETE",
        success: function (result) {
            getData();
        }
    });
}

function editItem(id) {
    $.each(books, function (key, item) {
        if (item.id === id) {
            $("#edit-title").val(item.title);
            $("#edit-id").val(item.id);
            $("#edit-author").val(item.author);
        }
    });
    $("#spoiler").css({ display: "block" });
}

function updateItem() {
    var id = parseInt($("#edit-id").val(), 10);
    const item = {
        id: id,
        title: $("#edit-title").val(),
        author: $("#edit-author").val(),
    };
    $.ajax({
        type: "POST",
        accepts: "application/json",
        url: uriBooks + '/UpdateBookItem',
        contentType: "application/json",
        data: JSON.stringify(item),
        error: function (jqXHR, textStatus, errorThrown) {
            alert("Something went wrong!");
        },
        success: function (result) {
            getData();
            closeInput();
        }
    });
}

function closeInput() {
    $("#spoiler").css({ display: "none" });
}