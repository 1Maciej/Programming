﻿const uriOsoba = "https://localhost:44354/api/Osoba";
let persons = null;
function getCount(data) {
    const el = $("#counter");
    let name = "osób";
    if (data) {
        if (data > 1) {
            name = "people";
        }
        el.text(data + " " + name);
    } else {
        el.text("brak " + name);
    }
}
$(document).ready(function () {
    getData();
});
function getData() {
    $.ajax({
        type: "GET",
        url: uriOsoba,
        cache: false,
        success: function (data) {
            const tBody = $("#persons");
            $(tBody).empty();
            getCount(data.length);
            $.each(data, function (key, item) {
                const tr = $("<tr></tr>")
                    .append($("<td></td>").text(item.name))
                    .append($("<td></td>").text(item.surname))
                    .append(
                        $("<td></td>").append(
                            $("<button>Edit</button>").on("click", function () {
                                editItem(item.id);
                            })
                        )
                    )
                    .append(
                        $("<td></td>").append(
                            $("<button>Delete</button>").on("click", function () {
                                deleteItem(item.id);
                            })
                        )
                    );
                tr.appendTo(tBody);
            });
            persons = data;
        }
    });
}
function addPerson() {
    const item = {
        name: $("#add-name").val(),
        surname: $("#add-surname").val(),
        isComplete: false
    };
    $.ajax({
        type: "POST",
        accepts: "application/json",
        url: uriOsoba + '/CreatePersonItem',
        contentType: "application/json",
        data: JSON.stringify(item),
        error: function (jqXHR, textStatus, errorThrown) {
            alert("Something went wrong!");
        },
        success: function (result) {
            getData();
            $("#add-name").val("");
            $("#add-surname").val("");
        }
    });
}

function deleteItem(id) {
    $.ajax({
        url: uriOsoba + "/" + id,
        type: "DELETE",
        success: function (result) {
            getData();
        }
    });
}

function editItem(id) {
    $.each(persons, function (key, item) {
        if (item.id === id) {
            $("#edit-name").val(item.name);
            $("#edit-id").val(item.id);
            $("#edit-surname").val(item.surname);
        }
    });
    $("#spoiler").css({ display: "block" });
}

function updateItem() {
    var id = parseInt($("#edit-id").val(), 10);
    const item = {
        id: id,
        name: $("#edit-name").val(),
        surname: $("#edit-surname").val(),
    };
    $.ajax({
        type: "POST",
        accepts: "application/json",
        url: uriOsoba + '/UpdatePersonItem',
        contentType: "application/json",
        data: JSON.stringify(item),
        error: function (jqXHR, textStatus, errorThrown) {
            alert("Something went wrong!");
        },
        success: function (result) {
            getData();
            closeInput();
        }
    });
}

function closeInput() {
    $("#spoiler").css({ display: "none" });
}