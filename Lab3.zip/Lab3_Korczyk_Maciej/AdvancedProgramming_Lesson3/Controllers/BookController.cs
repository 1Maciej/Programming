﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AdvancedProgramming_Lesson3.Models;
using Microsoft.EntityFrameworkCore;

namespace AdvancedProgramming_Lesson3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly BookContext _context;
        public BookController(BookContext context)
        {
            _context = context;
        }

        // GET: api/Book
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BookDTO>>> GetBookItems()
        {
            return await _context.BookItems
                .Select(x => ItemToDTO(x))
                .ToListAsync();
        }

        [HttpPost]
        [Route("CreateBookItem")]
        public async Task<ActionResult<Book>> CreateBookItem(BookDTO bookDTO)
        {
            var bookItem = new Book
            {
                Id = bookDTO.Id,
                Title = bookDTO.Title,
                Author = bookDTO.Author
            };

            _context.BookItems.Add(bookItem);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetBookItem),
                new { id = bookItem.Id },
                ItemToDTO(bookItem));
        }

        // GET: api/BookItems/5
        [HttpGet("{id}")]
        public async Task<ActionResult<BookDTO>> GetBookItem(long id)
        {
            var bookItem = await _context.BookItems.FindAsync(id);
            if (bookItem == null)
            {
                return NotFound();
            }

            return ItemToDTO(bookItem);
        }

        [HttpPost]
        [Route("UpdateBookItem")]
        public async Task<ActionResult<BookDTO>> UpdateBookItem(BookDTO bookDTO)
        {
            var bookItem = await _context.BookItems.FindAsync(bookDTO.Id);
            if (bookItem == null)
            {
                return NotFound();
            }
            bookItem.Title = bookDTO.Title;
            bookItem.Author = bookDTO.Author;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) when (!BookExists(bookDTO.Id))
            {
                return NotFound();
            }

            return CreatedAtAction(
                nameof(UpdateBookItem),
                new { id = bookItem.Id },
                ItemToDTO(bookItem));
        }

        // DELETE: api/Book/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Book>> DeleteBookItem(long id)
        {
            var bookItem = await _context.BookItems.FindAsync(id);
            if (bookItem == null)
            {
                return NotFound();
            }
            _context.BookItems.Remove(bookItem);
            await _context.SaveChangesAsync();
            return NoContent();
        }
        private bool BookExists(long id) =>
             _context.BookItems.Any(e => e.Id == id);
        private static BookDTO ItemToDTO(Book bookItem) =>
            new BookDTO
            {
                Id = bookItem.Id,
                Title = bookItem.Title,
                Author = bookItem.Author
            };
    }
}
