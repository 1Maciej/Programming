﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AdvancedProgramming_Lesson3.Models;
using Microsoft.EntityFrameworkCore;


namespace AdvancedProgramming_Lesson3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OsobaController : ControllerBase
    {
        private readonly OsobaContext _context;
        public OsobaController(OsobaContext context)
        {
            _context = context;
        }

        // GET: api/Osoba
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OsobaDTO>>> GetPersonItems()
        {
            return await _context.OsobaItems
                .Select(x => ItemToDTO(x))
                .ToListAsync();
        }

        [HttpPost]
        [Route("CreatePersonItem")]
        public async Task<ActionResult<Osoba>> CreatePersonItem(OsobaDTO osobaDTO)
        {
            var personItem = new Osoba
            {
                Id = osobaDTO.Id,
                Name = osobaDTO.Name,
                Surname = osobaDTO.Surname
            };

            _context.OsobaItems.Add(personItem);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetOsobaItem),
                new { id = personItem.Id },
                ItemToDTO(personItem));
        }

        // GET: api/OsobaItems/5
        [HttpGet("{id}")]
        public async Task<ActionResult<OsobaDTO>> GetOsobaItem(long id)
        {
            var todoItem = await _context.OsobaItems.FindAsync(id);
            if (todoItem == null)
            {
                return NotFound();
            }

            return ItemToDTO(todoItem);
        }

        [HttpPost]
        [Route("UpdatePersonItem")]
        public async Task<ActionResult<OsobaDTO>> UpdatePersonItem(OsobaDTO osobaDTO)
        {
            var osobaItem = await _context.OsobaItems.FindAsync(osobaDTO.Id);
            if (osobaItem == null)
            {
                return NotFound();
            }
            osobaItem.Name = osobaDTO.Name;
            osobaItem.Surname = osobaDTO.Surname;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) when (!OsobaExists(osobaDTO.Id))
            {
                return NotFound();
            }

            return CreatedAtAction(
                nameof(UpdatePersonItem),
                new { id = osobaItem.Id },
                ItemToDTO(osobaItem));
        }

        // DELETE: api/Osoba/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Osoba>> DeletePersonItem(long id)
        {
            var personItem = await _context.OsobaItems.FindAsync(id);
            if (personItem == null)
            {
                return NotFound();
            }
            _context.OsobaItems.Remove(personItem);
            await _context.SaveChangesAsync();
            return NoContent();
        }
        private bool OsobaExists(long id) =>
             _context.OsobaItems.Any(e => e.Id == id);
        private static OsobaDTO ItemToDTO(Osoba osobaItem) =>
            new OsobaDTO
            {
                Id = osobaItem.Id,
                Name = osobaItem.Name,
                Surname = osobaItem.Surname
            };
    }
}
